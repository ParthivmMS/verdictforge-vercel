# VerdictForge Vercel Version

Deployment-ready frontend for verdictforge.in
